<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-24 02:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 02:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 02:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 02:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 02:51:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 02:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 02:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 02:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 02:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 02:51:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 02:52:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 02:52:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 02:52:57 --> Severity: Warning --> mysqli::__construct(): (HY000/1049): Unknown database 'bd_5097' C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 14
ERROR - 2025-01-24 02:52:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 02:52:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 02:52:58 --> Severity: Warning --> mysqli::__construct(): (HY000/1049): Unknown database 'bd_5097' C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 14
ERROR - 2025-01-24 02:53:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 02:53:19 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 02:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 02:53:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 03:04:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:04:55 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 03:04:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:04:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 03:05:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:05:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 03:05:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:05:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 03:05:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:05:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 5
ERROR - 2025-01-24 03:15:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:15:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:15:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:15:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:15:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:15:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:15:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:15:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:15:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:15:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:15:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:15:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:15:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:15:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:15:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:15:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:15:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:15:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:15:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:15:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:15:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:15:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:15:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:15:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:15:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:15:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:15:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:17:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:17:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:17:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:17:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:17:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:21:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:21:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:21:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:21:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:21:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:21:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:21:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:21:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:21:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:21:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:21:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:21:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:29:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:29:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:29:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:29:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:29:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 03:29:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:29:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 03:29:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 03:29:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 03:29:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 03:29:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:04:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:04:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:04:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:04:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:04:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:04:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:04:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:04:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:04:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:04:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:04:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:04:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:05:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:05:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:05:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:05:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:05:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:05:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:05:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-24 04:05:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-24 04:05:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-24 04:05:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:07:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-24 04:07:10 --> Severity: Warning --> Undefined variable $jumlah_mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 04:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:24:01 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:43 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:44 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:45 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:45 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:45 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:45 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:45 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:46 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:46 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:46 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:46 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:47 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:47 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:47 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:47 --> Unable to connect to the database
ERROR - 2025-01-24 04:26:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:26:50 --> Unable to connect to the database
ERROR - 2025-01-24 04:47:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 04:47:51 --> Unable to connect to the database
ERROR - 2025-01-24 05:23:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 05:23:57 --> Unable to connect to the database
ERROR - 2025-01-24 05:25:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 05:25:39 --> Unable to connect to the database
ERROR - 2025-01-24 05:25:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wpu_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-24 05:25:40 --> Unable to connect to the database
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 05:26:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 05:26:37 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 06:33:05 --> Severity: Warning --> Undefined variable $jumlah_mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 06:59:15 --> Severity: Warning --> Undefined variable $jumlah_mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 07:11:43 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-24 07:17:24 --> Severity: Warning --> Undefined variable $jumlah_mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 07:35:35 --> Severity: Warning --> Undefined variable $jumlah_mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 08:01:44 --> 404 Page Not Found: Mahasiswa/index
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:09:27 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:50 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:50 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:51 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:11:51 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-24 08:15:13 --> Severity: Warning --> Undefined array key "nim" C:\xampp\htdocs\wpu-login\application\controllers\Mahasiswa.php 25
ERROR - 2025-01-24 08:15:13 --> Query error: Table 'wpu-login.mahasiswa' doesn't exist - Invalid query: SELECT *
FROM `mahasiswa`
WHERE `nim` IS NULL
ERROR - 2025-01-24 08:15:56 --> Severity: Warning --> Undefined array key "nim" C:\xampp\htdocs\wpu-login\application\controllers\Mahasiswa.php 25
ERROR - 2025-01-24 08:15:56 --> Query error: Table 'wpu-login.mahasiswa' doesn't exist - Invalid query: SELECT *
FROM `mahasiswa`
WHERE `nim` IS NULL
ERROR - 2025-01-24 08:42:04 --> Severity: Warning --> Undefined variable $jumlah_mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 09:08:29 --> Severity: Compile Error --> Cannot redeclare Dosen::index() C:\xampp\htdocs\wpu-login\application\controllers\Dosen.php 32
ERROR - 2025-01-24 09:08:43 --> Severity: Warning --> Undefined variable $jumlah_mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-24 09:10:52 --> Query error: Table 'wpu-login.mahasiswa' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `mahasiswa`
