<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-23 00:33:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\user\index.php 104
ERROR - 2025-01-23 00:33:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\user\index.php 104
ERROR - 2025-01-23 00:33:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\user\index.php 104
ERROR - 2025-01-23 00:40:46 --> Severity: 8192 --> Creation of dynamic property User::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 416
ERROR - 2025-01-23 00:40:46 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:40:48 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:40:49 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:17 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:17 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:18 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:24 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:25 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:25 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:26 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:41:28 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-23 00:47:21 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:18 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:21 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:21 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:22 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:22 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:22 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:23 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:23 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:56:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:57:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:57:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:57:26 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 00:57:27 --> 404 Page Not Found: Defaultjpg/index
ERROR - 2025-01-23 00:57:29 --> 404 Page Not Found: Defaultjpg/index
ERROR - 2025-01-23 00:57:30 --> 404 Page Not Found: Defaultjpg/index
ERROR - 2025-01-23 00:57:31 --> 404 Page Not Found: Defaultjpg/index
ERROR - 2025-01-23 00:57:31 --> 404 Page Not Found: Defaultjpg/index
ERROR - 2025-01-23 00:57:32 --> 404 Page Not Found: Defaultjpg/index
ERROR - 2025-01-23 01:06:42 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-23 01:06:44 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-23 01:06:45 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-23 01:06:46 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-23 01:14:59 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:00 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:01 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:02 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:02 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:02 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:02 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:03 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:15:04 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:18:44 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:18:45 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:18:45 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:18:45 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:18:45 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:34 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:34 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:35 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:35 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:35 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:36 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:36 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:36 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:36 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:37 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:19:37 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:10 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:11 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:11 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:11 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:12 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:12 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:12 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:16 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:16 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:21:16 --> Severity: error --> Exception: Call to undefined function data() C:\xampp\htdocs\wpu-login\application\views\user\index.php 142
ERROR - 2025-01-23 01:44:33 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 01:44:36 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 01:45:33 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 01:53:19 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 01:53:22 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 01:55:27 --> 404 Page Not Found: Auth/forgot-password.html
ERROR - 2025-01-23 01:59:13 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 03:12:34 --> 404 Page Not Found: Dosen/index
ERROR - 2025-01-23 03:30:13 --> Severity: Warning --> Undefined variable $matakuliah C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 03:30:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 03:30:22 --> 404 Page Not Found: Matakuliah/add
ERROR - 2025-01-23 03:30:23 --> Severity: Warning --> Undefined variable $matakuliah C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 03:30:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 03:30:55 --> Severity: Warning --> Undefined variable $matakuliah C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 03:30:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 03:32:16 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 03:32:18 --> Severity: Warning --> Undefined variable $matakuliah C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 03:32:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\user\index.php 38
ERROR - 2025-01-23 04:45:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 04:56:54 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 04:56:55 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 04:56:55 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 04:56:56 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 04:56:56 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 04:56:56 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:21:09 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 17
ERROR - 2025-01-23 05:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-23 05:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-23 05:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-23 05:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-23 05:29:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-23 05:29:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 17
ERROR - 2025-01-23 05:29:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 19
ERROR - 2025-01-23 05:30:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:30:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 22
ERROR - 2025-01-23 05:30:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 24
ERROR - 2025-01-23 05:32:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:32:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 19
ERROR - 2025-01-23 05:32:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-23 05:32:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-23 05:32:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-23 05:32:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-23 05:32:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_dosen\topbar.php 19
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 11
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 15
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 16
ERROR - 2025-01-23 05:33:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 17
ERROR - 2025-01-23 05:33:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 19
ERROR - 2025-01-23 05:33:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 05:33:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 19
ERROR - 2025-01-23 05:33:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 19
ERROR - 2025-01-23 05:35:40 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:36:11 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:36:11 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:36:11 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:36:19 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:36:56 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:39:37 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:40:00 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:40:01 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:40:01 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:40:01 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:40:02 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:43:57 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:44:00 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:44:00 --> 404 Page Not Found: User/index
ERROR - 2025-01-23 05:45:20 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 05:45:47 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 05:46:08 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 06:07:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_mahasiswa\topbar.php 19
ERROR - 2025-01-23 06:15:38 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 06:18:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:22:20 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\wpu-login\application\views\admin\index.php 74
ERROR - 2025-01-23 07:22:20 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\wpu-login\application\views\admin\index.php 74
ERROR - 2025-01-23 07:22:20 --> Severity: Warning --> Undefined array key "nama" C:\xampp\htdocs\wpu-login\application\views\admin\index.php 74
ERROR - 2025-01-23 07:23:44 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:23:46 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:23:49 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:23:52 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:24:06 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:46:50 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:46:59 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:47:30 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:51:03 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 07:58:09 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 07:58:13 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 08:02:22 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 08:12:04 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 08:26:36 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 08:28:23 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 08:29:07 --> 404 Page Not Found: Admin/input_data
ERROR - 2025-01-23 08:29:15 --> 404 Page Not Found: Admin/input_data
ERROR - 2025-01-23 08:29:42 --> 404 Page Not Found: Admin/input_data
ERROR - 2025-01-23 08:32:33 --> 404 Page Not Found: Admin/input_data
ERROR - 2025-01-23 08:33:40 --> 404 Page Not Found: Admin/Input%20Data%20Mahasiswa
ERROR - 2025-01-23 08:35:25 --> 404 Page Not Found: Admin/Input%20Data%20Mahasiswa
ERROR - 2025-01-23 08:39:21 --> 404 Page Not Found: Admin/Input%20Data%20Mahasiswa
ERROR - 2025-01-23 08:43:47 --> 404 Page Not Found: Admin/Input%20Data%20Mahasiswa
ERROR - 2025-01-23 09:27:29 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 09:29:47 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 09:30:56 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 09:30:56 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 09:31:10 --> 404 Page Not Found: Mahasisawa/index
ERROR - 2025-01-23 10:45:39 --> Severity: Warning --> Undefined variable $totalUsers C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 10
ERROR - 2025-01-23 10:45:39 --> Severity: Warning --> Undefined variable $activeUsers C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 18
ERROR - 2025-01-23 10:45:39 --> Severity: Warning --> Undefined variable $users C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 42
ERROR - 2025-01-23 10:45:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 42
ERROR - 2025-01-23 10:49:19 --> Severity: Warning --> Undefined variable $totalUsers C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 10
ERROR - 2025-01-23 10:49:19 --> Severity: Warning --> Undefined variable $activeUsers C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 18
ERROR - 2025-01-23 10:49:19 --> Severity: Warning --> Undefined variable $users C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 42
ERROR - 2025-01-23 10:49:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\admin\edit_data.php 42
ERROR - 2025-01-23 11:12:01 --> Severity: Warning --> Undefined variable $users C:\xampp\htdocs\wpu-login\application\views\admin\index.php 19
ERROR - 2025-01-23 11:12:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\admin\index.php 19
ERROR - 2025-01-23 11:12:27 --> 404 Page Not Found: Edit_userphp/index
ERROR - 2025-01-23 11:19:54 --> 404 Page Not Found: Edit_userphp/index
ERROR - 2025-01-23 11:20:05 --> 404 Page Not Found: Delete_userphp/index
ERROR - 2025-01-23 11:24:59 --> Severity: Warning --> Undefined variable $mata_kuliah C:\xampp\htdocs\wpu-login\application\views\admin\input_data.php 21
ERROR - 2025-01-23 11:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\admin\input_data.php 21
ERROR - 2025-01-23 11:31:10 --> 404 Page Not Found: Delete_userphp/index
ERROR - 2025-01-23 11:33:25 --> 404 Page Not Found: Delete_userphp/index
ERROR - 2025-01-23 11:34:07 --> 404 Page Not Found: Delete_userphp/index
ERROR - 2025-01-23 11:36:07 --> 404 Page Not Found: Admin/detele_admin3
ERROR - 2025-01-23 11:38:04 --> 404 Page Not Found: Admin/detele_admin3
ERROR - 2025-01-23 11:38:59 --> 404 Page Not Found: Admin/detele_admin3
ERROR - 2025-01-23 11:41:24 --> 404 Page Not Found: Admin/detele_admin3
ERROR - 2025-01-23 11:42:31 --> 404 Page Not Found: Admin/detele_admin3
ERROR - 2025-01-23 11:45:15 --> 404 Page Not Found: Admin/dashboard
ERROR - 2025-01-23 11:46:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model C:\xampp\htdocs\wpu-login\system\core\Loader.php 368
ERROR - 2025-01-23 11:51:57 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 11:51:58 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 11:52:01 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 13:19:13 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 13:25:09 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 13:30:37 --> 404 Page Not Found: Delete_userphp/index
ERROR - 2025-01-23 13:32:37 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 13:40:28 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:40:28 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:40:28 --> Severity: error --> Exception: Call to a member function prepare() on null C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:40:28 --> Severity: error --> Exception: Call to a member function prepare() on null C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:40:31 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:40:31 --> Severity: error --> Exception: Call to a member function prepare() on null C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:40:31 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:40:31 --> Severity: error --> Exception: Call to a member function prepare() on null C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:41:19 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:41:19 --> Severity: error --> Exception: Call to a member function prepare() on null C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:43:50 --> 404 Page Not Found: Edit_userphp/index
ERROR - 2025-01-23 13:47:48 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:47:48 --> Severity: error --> Exception: Call to a member function prepare() on null C:\xampp\htdocs\wpu-login\application\controllers\Admin.php 39
ERROR - 2025-01-23 13:56:36 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 13:59:56 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 14:03:42 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 14:03:51 --> 404 Page Not Found: Admin/delete_admin
ERROR - 2025-01-23 14:03:54 --> 404 Page Not Found: Edit_userphp/index
ERROR - 2025-01-23 14:04:51 --> 404 Page Not Found: Admin3/index
ERROR - 2025-01-23 14:18:22 --> 404 Page Not Found: Delete_userphp/index
ERROR - 2025-01-23 14:18:29 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 14:18:32 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 14:18:38 --> 404 Page Not Found: Edit_userphp/index
ERROR - 2025-01-23 14:21:46 --> 404 Page Not Found: Delete_userphp/index
ERROR - 2025-01-23 14:22:16 --> 404 Page Not Found: Admin3/index
ERROR - 2025-01-23 14:22:35 --> 404 Page Not Found: Admin3/index
ERROR - 2025-01-23 14:33:59 --> 404 Page Not Found: Edit_userphp/index
ERROR - 2025-01-23 14:51:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:53:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:53:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:53:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:53:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:53:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:54:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:54:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:54:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:56:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 14:56:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\templates_admin\topbar.php 19
ERROR - 2025-01-23 15:00:10 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 15:13:38 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 15:41:58 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 15:42:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-23 16:20:59 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 16:23:56 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 16:53:24 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 17:11:55 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 17:48:58 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 43
ERROR - 2025-01-23 17:48:58 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 43
ERROR - 2025-01-23 18:04:35 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 43
ERROR - 2025-01-23 18:04:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 43
ERROR - 2025-01-23 18:05:31 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 43
ERROR - 2025-01-23 18:05:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\wpu-login\application\views\dosen\index.php 43
ERROR - 2025-01-23 18:10:16 --> 404 Page Not Found: Nilai/tambah
ERROR - 2025-01-23 18:12:55 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 17
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 17
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 24
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 24
ERROR - 2025-01-23 18:17:27 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 24
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 25
ERROR - 2025-01-23 18:17:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 25
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 11
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 11
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 15
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 15
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 17
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 17
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 18
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 18
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 29
ERROR - 2025-01-23 18:27:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 29
ERROR - 2025-01-23 18:27:20 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 29
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:29:14 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:29:14 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:29:14 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:29:14 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:29:14 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:29:15 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:29:15 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:29:15 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:29:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:29:15 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:29:15 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:35:58 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:35:58 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:35:58 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:58 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:58 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 16
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:35:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 21
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:35:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 22
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:35:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 23
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Undefined variable $mahasiswa C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:59 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
ERROR - 2025-01-23 18:35:59 --> Severity: error --> Exception: date(): Argument #2 ($timestamp) must be of type ?int, string given C:\xampp\htdocs\wpu-login\application\views\mahasiswa\index.php 26
