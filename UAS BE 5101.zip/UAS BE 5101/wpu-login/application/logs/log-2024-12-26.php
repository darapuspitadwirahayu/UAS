<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-26 09:21:46 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:21:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:21:46 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:47 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:47 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:48 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:48 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:48 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:48 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:48 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:48 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:49 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:49 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:49 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:49 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:49 --> Unable to connect to the database
ERROR - 2024-12-26 09:24:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:24:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'nama_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:24:50 --> Unable to connect to the database
ERROR - 2024-12-26 09:25:18 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:25:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'name_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:25:18 --> Unable to connect to the database
ERROR - 2024-12-26 09:25:19 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:25:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'name_database' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:25:19 --> Unable to connect to the database
ERROR - 2024-12-26 09:27:16 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:27:16 --> Unable to connect to the database
ERROR - 2024-12-26 09:27:17 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:27:17 --> Unable to connect to the database
ERROR - 2024-12-26 09:27:25 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ci_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:27:25 --> Unable to connect to the database
ERROR - 2024-12-26 09:27:26 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ci_login' C:\xampp\htdocs\wpu-login\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-26 09:27:26 --> Unable to connect to the database
ERROR - 2024-12-26 09:27:41 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:41 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:41 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 949
ERROR - 2024-12-26 09:27:42 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:42 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\wpu-login\system\database\DB_driver.php 372
ERROR - 2024-12-26 09:27:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 949
ERROR - 2024-12-26 09:28:59 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 949
ERROR - 2024-12-26 09:36:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\templates\auth_header.php 12
ERROR - 2024-12-26 09:39:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\templates\auth_header.php 12
ERROR - 2024-12-26 09:52:34 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:35 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:36 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:36 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:36 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:36 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:36 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:37 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 09:52:40 --> Severity: error --> Exception: Unclosed '(' does not match ']' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 29
ERROR - 2024-12-26 10:11:42 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 21
ERROR - 2024-12-26 10:11:42 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 21
ERROR - 2024-12-26 10:11:46 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 21
ERROR - 2024-12-26 10:15:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\templates\auth_header.php 12
ERROR - 2024-12-26 10:15:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\templates\auth_header.php 12
ERROR - 2024-12-26 10:15:11 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\templates\auth_header.php 12
ERROR - 2024-12-26 10:15:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\wpu-login\application\views\templates\auth_header.php 12
ERROR - 2024-12-26 12:16:23 --> Severity: error --> Exception: Unclosed '{' on line 19 does not match ')' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 28
ERROR - 2024-12-26 12:20:24 --> Severity: error --> Exception: syntax error, unexpected string content "required|trim|valid_email|is_u...", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 76
ERROR - 2024-12-26 12:20:34 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 77
ERROR - 2024-12-26 12:20:36 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 77
ERROR - 2024-12-26 12:39:42 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 77
ERROR - 2024-12-26 12:40:01 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 76
ERROR - 2024-12-26 12:40:02 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 76
ERROR - 2024-12-26 12:40:02 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 76
ERROR - 2024-12-26 12:41:13 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 76
ERROR - 2024-12-26 12:41:14 --> Severity: error --> Exception: Unclosed '{' on line 73 C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 76
ERROR - 2024-12-26 12:41:26 --> Severity: error --> Exception: Unclosed '{' on line 19 does not match ')' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 28
ERROR - 2024-12-26 12:41:27 --> Severity: error --> Exception: Unclosed '{' on line 19 does not match ')' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 28
ERROR - 2024-12-26 12:41:27 --> Severity: error --> Exception: Unclosed '{' on line 19 does not match ')' C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 28
ERROR - 2024-12-26 12:42:23 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:23 --> Severity: error --> Exception: Undefined constant "this" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 24
ERROR - 2024-12-26 12:42:24 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:24 --> Severity: error --> Exception: Undefined constant "this" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 24
ERROR - 2024-12-26 12:42:24 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:24 --> Severity: error --> Exception: Undefined constant "this" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 24
ERROR - 2024-12-26 12:42:25 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:25 --> Severity: error --> Exception: Undefined constant "this" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 24
ERROR - 2024-12-26 12:42:25 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:25 --> Severity: error --> Exception: Undefined constant "this" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 24
ERROR - 2024-12-26 12:42:25 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:25 --> Severity: error --> Exception: Undefined constant "this" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 24
ERROR - 2024-12-26 12:42:25 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:25 --> Severity: error --> Exception: Undefined constant "this" C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 24
ERROR - 2024-12-26 12:42:35 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 12:42:36 --> Severity: Warning --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 22
ERROR - 2024-12-26 16:23:47 --> Severity: error --> Exception: Cannot use object of type Auth as array C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 44
ERROR - 2024-12-26 16:32:24 --> Severity: error --> Exception: Cannot use object of type Auth as array C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 44
ERROR - 2024-12-26 16:32:31 --> Severity: error --> Exception: Cannot use object of type Auth as array C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 44
ERROR - 2024-12-26 16:35:32 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:35:32 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:43:18 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:19 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:19 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:20 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:20 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:20 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:20 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:21 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:21 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:21 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:22 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:28 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:31 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:40 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:43:44 --> Severity: error --> Exception: Cannot access private property Auth::$db C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:46 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:46 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:47 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:47 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:48 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:48 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:48 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:48 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:58 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:58 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:58 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:58 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:59 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:59 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:59 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:59 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
ERROR - 2024-12-26 16:46:59 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2024-12-26 16:46:59 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 1302
