<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-22 13:35:32 --> 404 Page Not Found: User/index
ERROR - 2025-01-22 13:42:47 --> 404 Page Not Found: User/index
ERROR - 2025-01-22 13:50:05 --> Severity: 8192 --> Creation of dynamic property User::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 415
ERROR - 2025-01-22 14:01:12 --> Severity: error --> Exception: syntax error, unexpected token "class", expecting "function" or "const" C:\xampp\htdocs\wpu-login\system\core\Loader.php 72
ERROR - 2025-01-22 14:03:27 --> Severity: 8192 --> Creation of dynamic property User::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 416
ERROR - 2025-01-22 14:03:28 --> Severity: 8192 --> Creation of dynamic property User::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 416
ERROR - 2025-01-22 14:09:22 --> Severity: error --> Exception: Too few arguments to function User::__construct(), 0 passed in C:\xampp\htdocs\wpu-login\system\core\CodeIgniter.php on line 519 and exactly 1 expected C:\xampp\htdocs\wpu-login\application\controllers\User.php 8
ERROR - 2025-01-22 14:09:23 --> Severity: error --> Exception: Too few arguments to function User::__construct(), 0 passed in C:\xampp\htdocs\wpu-login\system\core\CodeIgniter.php on line 519 and exactly 1 expected C:\xampp\htdocs\wpu-login\application\controllers\User.php 8
ERROR - 2025-01-22 14:12:02 --> 404 Page Not Found: User/index
ERROR - 2025-01-22 14:12:03 --> 404 Page Not Found: User/index
ERROR - 2025-01-22 14:12:03 --> 404 Page Not Found: User/index
ERROR - 2025-01-22 14:12:03 --> 404 Page Not Found: User/index
ERROR - 2025-01-22 14:12:18 --> Severity: 8192 --> Creation of dynamic property User::$db is deprecated C:\xampp\htdocs\wpu-login\system\core\Loader.php 416
ERROR - 2025-01-22 14:30:43 --> 404 Page Not Found: User/uth
ERROR - 2025-01-22 14:31:21 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:33:04 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:33:08 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:33:24 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:33:25 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:33:34 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:35:26 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:35:26 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:35:36 --> 404 Page Not Found: User/auth
INFO - 2025-01-22 14:38:17 --> Config Class Initialized
INFO - 2025-01-22 14:38:17 --> Hooks Class Initialized
DEBUG - 2025-01-22 14:38:17 --> UTF-8 Support Enabled
INFO - 2025-01-22 14:38:17 --> Utf8 Class Initialized
INFO - 2025-01-22 14:38:17 --> URI Class Initialized
INFO - 2025-01-22 14:38:17 --> Router Class Initialized
INFO - 2025-01-22 14:38:17 --> Output Class Initialized
INFO - 2025-01-22 14:38:17 --> Security Class Initialized
DEBUG - 2025-01-22 14:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-22 14:38:17 --> Input Class Initialized
INFO - 2025-01-22 14:38:17 --> Language Class Initialized
ERROR - 2025-01-22 14:38:17 --> 404 Page Not Found: User/auth
INFO - 2025-01-22 14:38:19 --> Config Class Initialized
INFO - 2025-01-22 14:38:19 --> Hooks Class Initialized
DEBUG - 2025-01-22 14:38:19 --> UTF-8 Support Enabled
INFO - 2025-01-22 14:38:19 --> Utf8 Class Initialized
INFO - 2025-01-22 14:38:19 --> URI Class Initialized
INFO - 2025-01-22 14:38:19 --> Router Class Initialized
INFO - 2025-01-22 14:38:19 --> Output Class Initialized
INFO - 2025-01-22 14:38:19 --> Security Class Initialized
DEBUG - 2025-01-22 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-22 14:38:19 --> Input Class Initialized
INFO - 2025-01-22 14:38:19 --> Language Class Initialized
INFO - 2025-01-22 14:38:19 --> Loader Class Initialized
INFO - 2025-01-22 14:38:19 --> Helper loaded: url_helper
INFO - 2025-01-22 14:38:19 --> Helper loaded: file_helper
INFO - 2025-01-22 14:38:19 --> Helper loaded: security_helper
INFO - 2025-01-22 14:38:19 --> Database Driver Class Initialized
INFO - 2025-01-22 14:38:19 --> Email Class Initialized
DEBUG - 2025-01-22 14:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-01-22 14:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-22 14:38:19 --> Controller Class Initialized
INFO - 2025-01-22 14:38:19 --> Final output sent to browser
DEBUG - 2025-01-22 14:38:19 --> Total execution time: 0.2026
INFO - 2025-01-22 14:38:28 --> Config Class Initialized
INFO - 2025-01-22 14:38:28 --> Hooks Class Initialized
DEBUG - 2025-01-22 14:38:28 --> UTF-8 Support Enabled
INFO - 2025-01-22 14:38:28 --> Utf8 Class Initialized
INFO - 2025-01-22 14:38:28 --> URI Class Initialized
INFO - 2025-01-22 14:38:28 --> Router Class Initialized
INFO - 2025-01-22 14:38:28 --> Output Class Initialized
INFO - 2025-01-22 14:38:28 --> Security Class Initialized
DEBUG - 2025-01-22 14:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-22 14:38:28 --> Input Class Initialized
INFO - 2025-01-22 14:38:28 --> Language Class Initialized
ERROR - 2025-01-22 14:38:28 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:42:36 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:42:37 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:42:38 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:42:40 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:42:50 --> 404 Page Not Found: User/auth
ERROR - 2025-01-22 14:44:03 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-22 14:44:06 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-22 14:44:12 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-22 14:44:21 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-22 14:44:22 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-22 14:44:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:44:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:44:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:44:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:44:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:44:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:44:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:44:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:45:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:46:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:46:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:46:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 14:46:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\controllers\User.php 11
ERROR - 2025-01-22 15:04:07 --> 404 Page Not Found: Auth/login
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Vendor/fontawesome-free
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Css/sb-admin-2.min.css
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Vendor/jquery
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Js/sb-admin-2.min.js
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2025-01-22 16:08:29 --> 404 Page Not Found: Vendor/jquery-easing
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Assetsvendor/fontawesome-free
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Assetscss/sb-admin-2.min.css
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Assetsvendor/bootstrap
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Assetsvendor/jquery
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Assetsjs/sb-admin-2.min.js
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Assetsvendor/jquery-easing
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:21:07 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:21:14 --> 404 Page Not Found: Assetsvendor/fontawesome-free
ERROR - 2025-01-22 16:21:14 --> 404 Page Not Found: Assetscss/sb-admin-2.min.css
ERROR - 2025-01-22 16:23:27 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:23:27 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:23:27 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:23:27 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:35:11 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:35:12 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:35:12 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:35:12 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:35:12 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:35:26 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:35:26 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:35:26 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:35:26 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:35:26 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:41:25 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:41:25 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:41:25 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:41:25 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:41:25 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:42:35 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:42:35 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:42:35 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:42:35 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:42:35 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:42:41 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:42:41 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:42:41 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:42:41 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:42:41 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:43:06 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:43:07 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:43:07 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:43:07 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:43:07 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:52:17 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:52:17 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:52:17 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:52:17 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:52:17 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:54:41 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-22 16:54:44 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:55:11 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:55:11 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:55:11 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:55:11 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:55:11 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:55:46 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:55:46 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:55:46 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:55:46 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:55:46 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:56:16 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:56:16 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:56:16 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:56:16 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:56:16 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:57:23 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:57:23 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:57:23 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:57:23 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:57:23 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:57:39 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:57:39 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:57:39 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:57:39 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:57:39 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:57:56 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:57:57 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:57:57 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:57:57 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:57:57 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:57:58 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:57:58 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:57:58 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:57:58 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:57:58 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:58:34 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:58:34 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:58:34 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:58:34 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 16:58:34 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:59:04 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 16:59:04 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 16:59:04 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 16:59:04 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 16:59:04 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:00:05 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:00:05 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:00:05 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:00:05 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:00:05 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:00:16 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:00:16 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:00:16 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:00:16 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:00:16 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:03:11 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:03:11 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:03:11 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:03:11 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:03:11 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:03:31 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:03:31 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:03:31 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:03:31 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:03:31 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:03:57 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:03:57 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:03:57 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:03:57 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:03:57 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:04:18 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:04:18 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:04:18 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:04:18 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:04:18 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:04:30 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:04:30 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:04:30 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:04:30 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:04:30 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:04:39 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:04:39 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:04:39 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:04:39 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:04:39 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:04:40 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:04:40 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:04:40 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:04:40 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:04:40 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:05:10 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:05:10 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:05:10 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:05:10 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:05:10 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:05:42 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:05:42 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:05:42 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:05:42 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:05:42 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:07:40 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:07:40 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:07:40 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:07:40 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:07:40 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:08:11 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:08:11 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:08:11 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:08:11 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:08:11 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:12:04 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:12:04 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:12:04 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:12:04 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:12:04 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:13:15 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:13:15 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:13:15 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:13:15 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:13:15 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:15:03 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:15:04 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:15:04 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:15:04 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:15:04 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:15:05 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:15:05 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:15:05 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:15:05 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:15:05 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:16:30 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:16:30 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:16:30 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:16:30 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:16:30 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:17:08 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:17:08 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:17:08 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:17:08 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:17:08 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:17:12 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-22 17:17:13 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:17:15 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-22 17:17:16 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:23:30 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:23:30 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:23:30 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:23:30 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:23:30 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:23:32 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:23:33 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:23:33 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:23:33 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:23:33 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:23:43 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:23:43 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:23:43 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:23:43 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:23:43 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:25:21 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:25:21 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:25:21 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:25:22 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:25:22 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:25:45 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:25:46 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:25:46 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:25:46 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:25:46 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:25:58 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:25:58 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:25:58 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:25:58 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:25:58 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:26:05 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:26:05 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:26:05 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:26:05 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:26:05 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:26:26 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:26:27 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:26:27 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:26:27 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:26:27 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:26:38 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:26:38 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:26:38 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:26:38 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:26:38 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:28:13 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:28:13 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2025-01-22 17:28:13 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:28:13 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2025-01-22 17:28:13 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2025-01-22 17:32:16 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:32:16 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:33:33 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:33:33 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:33:34 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:33:34 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:33:34 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:33:34 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:33:34 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:33:34 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:35:10 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:35:10 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\wpu-login\application\views\user\index.php 94
ERROR - 2025-01-22 17:35:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\wpu-login\application\views\user\index.php 94
ERROR - 2025-01-22 17:35:10 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:37:27 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\User.php 12
ERROR - 2025-01-22 17:37:28 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\User.php 12
ERROR - 2025-01-22 17:37:28 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\User.php 12
ERROR - 2025-01-22 17:37:29 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\User.php 12
ERROR - 2025-01-22 17:37:29 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\User.php 12
ERROR - 2025-01-22 17:37:29 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\User.php 12
ERROR - 2025-01-22 17:37:29 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\wpu-login\application\controllers\User.php 12
ERROR - 2025-01-22 17:38:04 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:38:04 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:39:40 --> Severity: Warning --> Undefined variable $tittle C:\xampp\htdocs\wpu-login\application\views\user\index.php 12
ERROR - 2025-01-22 17:39:40 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:40:42 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:40:43 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:40:43 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:40:44 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:40:46 --> 404 Page Not Found: Chartshtml/index
ERROR - 2025-01-22 17:40:49 --> 404 Page Not Found: Indexhtml/index
ERROR - 2025-01-22 17:41:32 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:41:33 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:41:34 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:41:34 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 17:41:35 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2025-01-22 18:12:42 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:12:45 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:12:47 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:12:49 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:12:51 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:35 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:36 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:37 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:37 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:37 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:37 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:37 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:38 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:17:38 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:18:37 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:18:38 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:18:38 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:18:39 --> 404 Page Not Found: Assets/img
ERROR - 2025-01-22 18:31:07 --> 404 Page Not Found: Loginhtml/index
ERROR - 2025-01-22 18:42:26 --> 404 Page Not Found: Indexhtml/index
