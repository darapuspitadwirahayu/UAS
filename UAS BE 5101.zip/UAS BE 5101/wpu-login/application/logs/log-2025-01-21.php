<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-21 04:42:30 --> 404 Page Not Found: User/index
