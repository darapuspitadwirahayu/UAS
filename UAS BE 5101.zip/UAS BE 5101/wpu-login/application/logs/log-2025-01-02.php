<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-01-02 07:56:14 --> Severity: error --> Exception: Cannot use object of type Auth as array C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 44
ERROR - 2025-01-02 07:57:20 --> Severity: error --> Exception: Cannot use object of type Auth as array C:\xampp\htdocs\wpu-login\application\controllers\Auth.php 44
ERROR - 2025-01-02 08:11:02 --> 404 Page Not Found: User/index
ERROR - 2025-01-02 08:11:11 --> 404 Page Not Found: User/index
