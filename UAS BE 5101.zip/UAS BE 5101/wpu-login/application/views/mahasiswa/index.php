<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $tittle; ?></h1>

    <!-- Container Profil Mahasiswa -->
    <div class="container mb-4">
        <h2>Data Mahasiswa</h2>

        <!-- Card Informasi Mahasiswa -->
        <div class="card mb-3" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <!-- Gambar Profil -->
                    <img src="<?= base_url('assets/img/profile/') . $mahasiswa['image']; ?>" class="img-fluid rounded-start" alt="Foto Mahasiswa">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <!-- Informasi Mahasiswa -->
                        <h5 class="card-title"><?= htmlspecialchars($mahasiswa['name']); ?></h5>
                        <p class="card-text">NIM: <?= htmlspecialchars($mahasiswa['nim']); ?></p>
                        <p class="card-text">Program Studi: <?= htmlspecialchars($mahasiswa['prodi']); ?></p>
                        <p class="card-text">
                            <small class="text-body-secondary">
                                Terdaftar sejak <?= date('d F Y', htmlspecialchars($mahasiswa['date_created'])); ?>
                            </small>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Container IPK Mahasiswa -->
    <div class="container">
        <h2>IPK Mahasiswa</h2>
        <div class="alert alert-info" role="alert" style="max-width: 300px;">
            <strong>IPK:</strong> <?= number_format($mahasiswa['ipk'], 2); ?>
        </div>
    </div>

</div>
<!-- End Page Content -->
