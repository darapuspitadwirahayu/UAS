<div class="container mt-5 mb-5"> <!-- Tambahkan "mb-5" untuk jarak bawah -->
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h3 class="text-center mb-4">Input Data Mata Kuliah</h3>

                <!-- Menampilkan pesan sukses -->
                <?php if ($this->session->flashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= html_escape($this->session->flashdata('success')); ?>
                    </div>
                <?php endif; ?>

                <!-- Form Input Data Mata Kuliah -->
                <form action="<?= site_url('matakuliah/simpan'); ?>" method="post">
                    <div class="form-group">
                        <label for="nama_dosen">Nama Dosen:</label>
                        <input type="text" class="form-control" name="nama_dosen" id="nama_dosen" placeholder="Masukkan Nama Dosen" required autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label for="nama_mk">Nama Mata Kuliah:</label>
                        <input type="text" class="form-control" name="nama_mk" id="nama_mk" placeholder="Masukkan Nama Mata Kuliah" required autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label for="sks">Jumlah SKS:</label>
                        <input type="number" class="form-control" name="sks" id="sks" placeholder="Masukkan Jumlah SKS" required autocomplete="off">
                    </div>

                    <button type="submit" class="btn btn-primary btn-custom btn-block">Simpan Data</button>
                </form>
            </div>
        </div>
    </div>
</div>
