<?php
// Koneksi ke database
$host = 'localhost';
$dbname = 'wpu-login';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Hitung total users
    $totalUsersStmt = $pdo->query("SELECT COUNT(*) AS total_users FROM user");
    $totalUsers = $totalUsersStmt->fetch(PDO::FETCH_ASSOC)['total_users'];

    // Hitung users aktif
    $activeUsersStmt = $pdo->query("SELECT COUNT(*) AS active_users FROM user WHERE is_active = 1");
    $activeUsers = $activeUsersStmt->fetch(PDO::FETCH_ASSOC)['active_users'];

    // Ambil data users dengan role_id 2 dan 3
    $usersStmt = $pdo->prepare("SELECT id, name, email, role_id, is_active FROM user WHERE role_id IN (1, 2, 3)");
    $usersStmt->execute();
    $users = $usersStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Summary Section -->
    <div class="row">
        <div class="col-md-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Users</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalUsers; ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Active Users</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $activeUsers; ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Users Table Section -->
    <div class="card shadow mt-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">User Login Data</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= htmlspecialchars($user['id']); ?></td>
                                <td><?= htmlspecialchars($user['name']); ?></td>
                                <td><?= htmlspecialchars($user['email']); ?></td>
                                <td><?= $user['is_active'] ? 'Active' : 'Inactive'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- /.container-fluid -->