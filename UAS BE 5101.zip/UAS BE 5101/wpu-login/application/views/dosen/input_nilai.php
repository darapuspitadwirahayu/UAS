<div class="container mt-5 mb-5">
    <!-- Tambahkan margin atas dan bawah -->
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h3 class="text-center mb-4">Input Nilai Mahasiswa</h3>

                <!-- Menampilkan pesan sukses -->
                <?php if ($this->session->flashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= html_escape($this->session->flashdata('success')); ?>
                    </div>
                <?php endif; ?>

                <!-- Form Input Nilai Mahasiswa -->
                <form action="<?= site_url('nilaimahasiswa/simpan'); ?>" method="post">
                    <!-- Input NIM -->
                    <div class="form-group">
                        <label for="nim">NIM:</label>
                        <input type="text" class="form-control" name="nim" id="nim" placeholder="Masukkan NIM Mahasiswa" required autocomplete="off">
                    </div>

                    <!-- Input Nama -->
                    <div class="form-group">
                        <label for="nama">Nama Mahasiswa:</label>
                        <input type="text" class="form-control" name="nama" id="nama" placeholder="Masukkan Nama Mahasiswa" required autocomplete="off">
                    </div>

                    <!-- Input Mata Kuliah -->
                    <div class="form-group">
                        <label for="mata_kuliah">Mata Kuliah:</label>
                        <input type="text" class="form-control" name="mata_kuliah" id="mata_kuliah" placeholder="Masukkan Mata Kuliah" required autocomplete="off">
                    </div>

                    <!-- Input SKS -->
                    <div class="form-group">
                        <label for="sks">Jumlah SKS:</label>
                        <input type="number" class="form-control" name="sks" id="sks" placeholder="Masukkan Jumlah SKS" required autocomplete="off">
                    </div>

                    <!-- Input Nilai -->
                    <div class="form-group">
                        <label for="nilai">Nilai:</label>
                        <input type="number" class="form-control" name="nilai" id="nilai" placeholder="Masukkan Nilai Mahasiswa" step="0.01" required autocomplete="off">
                    </div>

                    <!-- Tombol Submit -->
                    <button type="submit" class="btn btn-primary btn-custom btn-block">Simpan Data</button>
                </form>
            </div>
        </div>
    </div>
</div>
