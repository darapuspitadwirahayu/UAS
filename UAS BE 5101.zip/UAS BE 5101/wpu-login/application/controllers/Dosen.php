<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dosen extends CI_Controller
{
    public $db;

    public function index()
    {
        $data['tittle'] = 'Dashboard Dosen';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        // Ambil jumlah mahasiswa dari tabel mahasiswa
        $data['jumlah_mahasiswa'] = $this->db->count_all('mahasiswa');  // Hitung jumlah mahasiswa

        // Memuat view dengan data yang sudah ditambahkan
        $this->load->view('templates_dosen/header', $data);
        $this->load->view('templates_dosen/sidebar', $data);
        $this->load->view('templates_dosen/topbar', $data);
        $this->load->view('dosen/index', $data);  // Di sini data['jumlah_mahasiswa'] akan tersedia
        $this->load->view('templates_dosen/footer');
    }

    public function input_nilai()
    {
        $data['tittle'] = 'Dashboard Dosen';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates_dosen/header', $data);
        $this->load->view('templates_dosen/sidebar', $data);
        $this->load->view('templates_dosen/topbar', $data);
        $this->load->view('dosen/input_nilai', $data);
        $this->load->view('templates_dosen/footer');
    }
}
