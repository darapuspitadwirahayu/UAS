<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mahasiswa extends CI_Controller
{
    public function index()
    {
        // Judul halaman
        $data['tittle'] = 'Dashboard Mahasiswa';

        // Mendapatkan email dari sesi
        $email = $this->session->userdata('email');
        if (!$email) {
            redirect('auth/login'); // Redirect jika sesi tidak valid
        }

        // Mendapatkan data user berdasarkan email
        $data['user'] = $this->db->get_where('user', ['email' => $email])->row_array();
        if (empty($data['user'])) {
            show_error('Data user tidak ditemukan. Silakan periksa kembali.');
        }

        // Pastikan NIM ada di data user
        if (empty($data['user']['nim'])) {
            show_error('NIM tidak ditemukan pada data user. Pastikan data NIM terisi di tabel user.');
        }

        // Mendapatkan data mahasiswa berdasarkan NIM
        $data['mahasiswa'] = $this->db->get_where('mahasiswa', ['nim' => $data['user']['nim']])->row_array();
        if (empty($data['mahasiswa'])) {
            $data['mahasiswa'] = [
                'image' => 'default.jpg',
                'name' => 'Tidak Diketahui',
                'nim' => '0000000000',
                'prodi' => 'Tidak Diketahui',
                'date_created' => time(),
                'ipk' => 0.00
            ];
        }

        // Tambahkan query untuk menghitung jumlah mahasiswa
        $data['jumlah_mahasiswa'] = $this->db->count_all('mahasiswa');

        // Memuat view dengan data
        $this->load->view('templates_mahasiswa/header', $data);
        $this->load->view('templates_mahasiswa/sidebar', $data);
        $this->load->view('templates_mahasiswa/topbar', $data);
        $this->load->view('mahasiswa/index', $data);
        $this->load->view('templates_mahasiswa/footer');
    }
}
